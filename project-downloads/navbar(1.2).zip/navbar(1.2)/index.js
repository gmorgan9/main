function toggleMobileMenu(menu) {
    menu.classList.toggle('open');
}